---
name: deckpal
description: Coach a Pokémon TCG player through their DeckPal account (the DeckPal connector). Use whenever the user pastes a PTCG Live battle log, asks to log or review games, asks how a deck is doing, wants to build or change a deck, asks a card or rules question, logs cards, asks about set completion, lists, carts or prices, or wants to undo a DeckPal change.
---

# DeckPal

DeckPal keeps its own step-by-step playbooks for every job, current with the tools it serves. This skill only says where they are.

1. Before your first DeckPal tool call for a job, call DeckPal's `playbook` tool with no name. It returns the rules for every job and which playbook fits the request.
2. Call `playbook` again with that playbook's name, and follow it.
3. If the DeckPal connector is not connected, say so: these jobs need it (deckpal.app/connect).
4. If the connector has no `playbook` tool, read the same playbooks at https://deckpal.app/skill.
